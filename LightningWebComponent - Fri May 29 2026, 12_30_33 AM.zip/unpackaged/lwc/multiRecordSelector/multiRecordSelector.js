import { LightningElement, wire, api, track } from 'lwc';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi'
import NAME_FIELD from '@salesforce/schema/Account.Name';

export default class MultiRecordSelector extends LightningElement {
    @api selectedrecord;
    accountid;
    accountName;
    @track items = [];
    handlechanges(event) {
        console.log(JSON.stringify(event));
        this.selectedrecord = event.detail.recordId;

    }

    @wire(getRecord, { recordId: '$selectedrecord', fields: [NAME_FIELD] })
    wiredAccount({ error, data }) {
        if (data) {
            this.accountLabel = getFieldValue(data, NAME_FIELD); // Maps to Name
            this.accountid = this.selectedrecord;                  // Maps to Id

            console.log('Label:', this.accountLabel);
            console.log('id:', this.accountid);


            if (!this.items.some(item => item.name === this.accountid)) {
                this.items = [
                    ...this.items,
                    {
                        label: this.accountLabel,
                        name: this.accountid
                    }
                ];
            }
        }
        else if (error) {
            console.error('error', error);

        }

        const recordPicker = this.template.querySelector('lightning-record-picker');

        if (recordPicker) {
            recordPicker.clearSelection();
        }
    }



handleItemRemove(event){
   const itemName = event.detail.item.name;

        // Remove the item using filter to create a new array and trigger reactivity
        this.items = this.items.filter(item => item.name !== itemName);
    }

}